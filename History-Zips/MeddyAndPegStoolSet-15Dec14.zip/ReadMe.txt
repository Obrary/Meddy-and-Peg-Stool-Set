Product: Meddy and Peg Stool Set, December 2014

Designer: James Thibault

Support:  http://forums.obrary.com/category/designs/meddy-and-peg-stool-set

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design